const API_URL = 'http://localhost:3000';

async function registerUser(nome, email, password) {
    const response = await fetch(`${API_URL}/auth/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ nome, email, password, ruolo: 'utente' })
    });
    return response.json();
}

async function loginUser(email, password) {
    const response = await fetch(`${API_URL}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
    });
    return response.json();
}

async function fetchRestaurants() {
    const response = await fetch(`${API_URL}/restaurants`);
    return response.json();
}

async function addReview(ristorante_id, utente_id, voto, commento) {
    const token = localStorage.getItem('token');
    const response = await fetch(`${API_URL}/reviews`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ ristorante_id, utente_id, voto, commento })
    });
    return response.json();
}
