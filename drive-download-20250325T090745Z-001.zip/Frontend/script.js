document.addEventListener('DOMContentLoaded', () => {
    const loginBtn = document.getElementById('login-btn');
    const registerBtn = document.getElementById('register-btn');
    const logoutBtn = document.getElementById('logout-btn');
    const authSubmit = document.getElementById('auth-submit');
    const restaurantList = document.getElementById('restaurant-list');
    const reviewList = document.getElementById('review-list');
    const submitReview = document.getElementById('submit-review');

    let isLoginMode = true;

    function toggleAuthMode() {
        isLoginMode = !isLoginMode;
        document.getElementById('auth-name').style.display = isLoginMode ? 'none' : 'block';
    }

    loginBtn.addEventListener('click', toggleAuthMode);
    registerBtn.addEventListener('click', toggleAuthMode);

    authSubmit.addEventListener('click', async () => {
        const nome = document.getElementById('auth-name').value;
        const email = document.getElementById('auth-email').value;
        const password = document.getElementById('auth-password').value;

        let response;
        if (isLoginMode) {
            response = await loginUser(email, password);
        } else {
            response = await registerUser(nome, email, password);
        }

        if (response.token) {
            localStorage.setItem('token', response.token);
            logoutBtn.style.display = 'block';
            alert('Autenticazione avvenuta con successo!');
        } else {
            alert('Errore di autenticazione!');
        }
    });

    logoutBtn.addEventListener('click', () => {
        localStorage.removeItem('token');
        logoutBtn.style.display = 'none';
        alert('Logout effettuato');
    });

    async function loadRestaurants() {
        const restaurants = await fetchRestaurants();
        restaurantList.innerHTML = '';
        restaurants.forEach(resto => {
            const li = document.createElement('li');
            li.textContent = `${resto.nome} - ${resto.tipo_cucina} - ${resto.fascia_prezzo}`;
            li.dataset.id = resto.id;
            li.addEventListener('click', () => loadReviews(resto.id));
            restaurantList.appendChild(li);
        });
    }

    async function loadReviews(ristorante_id) {
        const response = await fetch(`${API_URL}/reviews/${ristorante_id}`);
        const reviews = await response.json();
        reviewList.innerHTML = '';
        reviews.forEach(rev => {
            const li = document.createElement('li');
            li.textContent = `${rev.voto}/5 - ${rev.commento}`;
            reviewList.appendChild(li);
        });
    }

    submitReview.addEventListener('click', async () => {
        const commento = document.getElementById('review-text').value;
        const voto = document.getElementById('review-rating').value;
        await addReview(1, 1, voto, commento);
        loadReviews(1);
    });

    loadRestaurants();
});

