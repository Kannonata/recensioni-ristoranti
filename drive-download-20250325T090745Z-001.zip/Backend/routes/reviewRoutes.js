const express = require('express');
const { addReview, getReviewsByRestaurant } = require('../controllers/reviewController');

const router = express.Router();

router.post('/', addReview);
router.get('/:ristorante_id', getReviewsByRestaurant);

module.exports = router;
