const pool = require('../config/db');

async function getRatingByRestaurant(ristorante_id) {
    try {
        const [result] = await pool.query(
            'SELECT valutazione_media, numero_recensioni FROM valutazioni WHERE ristorante_id = ?',
            [ristorante_id]
        );
        return result[0] || null;
    } catch (err) {
        throw new Error('Errore nel recupero delle valutazioni: ' + err.message);
    }
}

async function updateRestaurantRating(ristorante_id) {
    try {
        const [reviews] = await pool.query(
            'SELECT AVG(voto) AS media, COUNT(*) AS conteggio FROM recensioni WHERE ristorante_id = ?',
            [ristorante_id]
        );

        const media = reviews[0].media || 0;
        const conteggio = reviews[0].conteggio || 0;

        await pool.query(
            'UPDATE valutazioni SET valutazione_media = ?, numero_recensioni = ? WHERE ristorante_id = ?',
            [media, conteggio, ristorante_id]
        );
    } catch (err) {
        throw new Error('Errore nell\'aggiornamento delle valutazioni: ' + err.message);
    }
}

module.exports = { getRatingByRestaurant, updateRestaurantRating };
