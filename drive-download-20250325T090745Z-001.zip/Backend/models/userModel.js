const pool = require('../config/db');

async function createUser(nome, email, password, ruolo) {
    const [result] = await pool.query(
        'INSERT INTO utenti (nome, email, password, ruolo) VALUES (?, ?, ?, ?)',
        [nome, email, password, ruolo]
    );
    return result.insertId;
}

module.exports = { createUser };
