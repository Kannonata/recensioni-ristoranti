const pool = require('../config/db');

async function addReview(ristorante_id, utente_id, voto, commento) {
    try {
        const [result] = await pool.query(
            'INSERT INTO recensioni (ristorante_id, utente_id, voto, commento) VALUES (?, ?, ?, ?)',
            [ristorante_id, utente_id, voto, commento]
        );

        return result.insertId;
    } catch (err) {
        throw new Error('Errore nell\'aggiunta della recensione: ' + err.message);
    }
}

async function getReviewsByRestaurant(ristorante_id) {
    try {
        const [reviews] = await pool.query(
            'SELECT * FROM recensioni WHERE ristorante_id = ?',
            [ristorante_id]
        );
        return reviews;
    } catch (err) {
        throw new Error('Errore nel recupero delle recensioni: ' + err.message);
    }
}

module.exports = { addReview, getReviewsByRestaurant };
