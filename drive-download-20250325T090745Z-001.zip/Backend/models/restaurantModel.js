const pool = require('../config/db');

async function createRestaurant(nome, indirizzo, tipo_cucina, fascia_prezzo, proprietario_id) {
    const [result] = await pool.query(
        'INSERT INTO ristoranti (nome, indirizzo, tipo_cucina, fascia_prezzo, proprietario_id) VALUES (?, ?, ?, ?, ?)',
        [nome, indirizzo, tipo_cucina, fascia_prezzo, proprietario_id]
    );
    return result.insertId;
}

module.exports = { createRestaurant };
