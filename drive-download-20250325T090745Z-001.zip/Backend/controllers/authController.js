const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const pool = require('../config/db');

async function register(req, res) {
    const { nome, email, password, ruolo } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);

    try {
        const [result] = await pool.query(
            'INSERT INTO utenti (nome, email, password, ruolo) VALUES (?, ?, ?, ?)',
            [nome, email, hashedPassword, ruolo]
        );

        const token = jwt.sign({ id: result.insertId, ruolo }, process.env.JWT_SECRET);
        res.json({ token });
    } catch (err) {
        res.status(500).json({ message: 'Errore durante la registrazione', error: err });
    }
}

async function login(req, res) {
    const { email, password } = req.body;

    try {
        const [users] = await pool.query('SELECT * FROM utenti WHERE email = ?', [email]);
        if (users.length === 0) return res.status(400).json({ message: 'Utente non trovato' });

        const user = users[0];
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) return res.status(400).json({ message: 'Password errata' });

        const token = jwt.sign({ id: user.id, ruolo: user.ruolo }, process.env.JWT_SECRET);
        res.json({ token });
    } catch (err) {
        res.status(500).json({ message: 'Errore durante il login', error: err });
    }
}

module.exports = { register, login };
