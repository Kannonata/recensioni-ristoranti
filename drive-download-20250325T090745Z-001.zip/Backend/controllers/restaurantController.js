const pool = require('../config/db');

async function getRestaurants(req, res) {
    try {
        const [restaurants] = await pool.query('SELECT * FROM ristoranti');
        res.json(restaurants);
    } catch (err) {
        res.status(500).json({ message: 'Errore nel recupero dei ristoranti', error: err });
    }
}

async function addRestaurant(req, res) {
    const { nome, indirizzo, tipo_cucina, fascia_prezzo, proprietario_id } = req.body;

    try {
        await pool.query(
            'INSERT INTO ristoranti (nome, indirizzo, tipo_cucina, fascia_prezzo, proprietario_id) VALUES (?, ?, ?, ?, ?)',
            [nome, indirizzo, tipo_cucina, fascia_prezzo, proprietario_id]
        );
        res.json({ message: 'Ristorante aggiunto con successo' });
    } catch (err) {
        res.status(500).json({ message: 'Errore nell\'aggiunta del ristorante', error: err });
    }
}

module.exports = { getRestaurants, addRestaurant };
