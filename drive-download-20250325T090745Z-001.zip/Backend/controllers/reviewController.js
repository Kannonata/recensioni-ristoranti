const pool = require('../config/db');

async function addReview(req, res) {
    const { ristorante_id, utente_id, voto, commento } = req.body;

    try {
        await pool.query(
            'INSERT INTO recensioni (ristorante_id, utente_id, voto, commento) VALUES (?, ?, ?, ?)',
            [ristorante_id, utente_id, voto, commento]
        );
        res.json({ message: 'Recensione aggiunta con successo' });
    } catch (err) {
        res.status(500).json({ message: 'Errore nell\'aggiunta della recensione', error: err });
    }
}

async function getReviewsByRestaurant(req, res) {
    const { ristorante_id } = req.params;

    try {
        const [reviews] = await pool.query(
            'SELECT * FROM recensioni WHERE ristorante_id = ?',
            [ristorante_id]
        );
        res.json(reviews);
    } catch (err) {
        res.status(500).json({ message: 'Errore nel recupero delle recensioni', error: err });
    }
}

module.exports = { addReview, getReviewsByRestaurant };
